const express = require('express');
const dotenv = require('dotenv');
const {checkout,paymentVerification} = require('../controllers/paymentControllers');

const router = express.Router();
dotenv.config();

router.route("/checkout").post(checkout);
router.route("/paymentverification").post(paymentVerification);

  module.exports = router;
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const cors = require('cors');
const express = require('express');
const router = express.Router();
const User = require('../models/users.model');

const app = express();
app.use(express.json());
app.use(cors());

router.get('/', async(req,res) => {
    let user = await User.find();
    res.send(user);
});
// User Registration

router.post('/register', async (req, res) => {
    const user = new User({
        username: req.body.username,
        email: req.body.email,
        password: req.body.password
    });
    try {
        const newUser = await user.save();
        res.status(201).json({newUser, message: 'User Registered Successfully.'});
    } catch (error) {
        res.send({ message: error.message });
    }
});

router.post('/login', async (req, res) => {
    try {
        const { email, password } = req.body;
            const user = await User.findOne({ email,password });
        console.log(user);
        if (!user) {
            return res.status(401).json({ message: 'Invalid Email or Password.' });
        }

        res.status(200).json({
            _id: user.id,
            username: user.username,
            email: user.email,
            message: 'User Logged In Successfully.',
            createdAt: user.createdAt,
            updatedAt: user.updated
        }); 
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Something went wrong. Please try again later.' });
    }
});   

router.put('/update/:id', async (req, res) => {
    const { id } = req.params;
    const { username, email, password } = req.body;

    try {
        const updates = {};
        if (username !== undefined) updates.username = username;
        if (email !== undefined) updates.email = email;
        if (password !== undefined) updates.password = password;
        
        const updatedUser = await User.findByIdAndUpdate(
          id,
          updates,
          { new: true, runValidators: true }
        );

        res.status(200).json({ updatedUser, message: 'User Updated Successfully.' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Something went wrong. Please try again later.' });
    }
});

const adminSchema = new mongoose.Schema({
    username:String,
    email:String,
    password:String,
},{timestamps:true});
const Admin = mongoose.model("Admin",adminSchema);

router.post('/adminregister', async(req, res) => {
    const {username,email,password}= req.body;
    const admin = new Admin({
    username,
     email,
     password   
    })
    const newAdmin = await admin.save();
    res.status(201).send({newAdmin,message: 'Admin Registered Successfully.'});
});

router.post('/adminlogin', async(req, res) => {
    try {
        const {email,password}= req.body;
        const admin = await Admin.findOne({email,password});
        if(!admin){
            return res.status(401).json({ message: 'Invalid Email or Password.' });   
        }
        res.status(200).send({admin,message: 'Admin LoggedIn Successfully.'});
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Something went wrong. Please try again later.' });
    }
});

router.delete('/delete/:id', async (req, res) => {
    const { id } = req.params;
  
    try {
      const deletedUser = await User.findByIdAndDelete(id);
  
      if (!deletedUser) {
        return res.status(404).json({ message: 'User not found.' });
      }
  
      res.status(200).json({ message: 'User deleted successfully.' });
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Something went wrong. Please try again later.' });
    }
  });
  


module.exports = router;
const Razorpay = require('razorpay');
const dotenv = require('dotenv');
dotenv.config();

const instance = new Razorpay({
    key_id: process.env.KEY_ID,
    key_secret:process.env.KEY_SECRET, // Replace with your Razorpay Key Secret
});

const checkout= async (req, res) => { 
    try {
        const options = {
        amount: req.body.amount, // amount in the smallest currency unit
        currency: "INR",
        };
        const order = await instance.orders.create(options);
        res.status(200).json(order);
    } catch (error) {
        console.log(error);
        res.status(500).json({ message: "Internal Server Error" });
    }
    }

    const paymentVerification= async (req, res) => { 
       res.status(200).json({success:true});
        }; 

    module.exports = {checkout,paymentVerification};
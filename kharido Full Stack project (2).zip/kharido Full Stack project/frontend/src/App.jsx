import Header from './components/Header'
import Allroutes from './routes/Allroutes.jsx';
import './App.css'

function App() {

  return (
    <>
      <div className='App'>
        <Allroutes></Allroutes>
      </div>     
    </>
  )
}

export default App

# Admin login
email : admin@gmail.com
password : 123

# For user login you can create your id by sigup and rhen log in

# developer
name : Anurag Singh
phone number : 8595887191